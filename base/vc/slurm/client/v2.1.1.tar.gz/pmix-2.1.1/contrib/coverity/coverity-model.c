void pmix_bogus_function_for_coverity_model(void) {
    __coverity_panic__();
}
